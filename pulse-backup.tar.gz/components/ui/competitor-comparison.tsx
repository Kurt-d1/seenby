"use client"

import { Button } from "./button"
import { ScoreRing } from "./score-ring"

interface CompetitorAnalysis {
  place_id: string
  name: string
  address: string
  google: {
    rating: number | null
    review_count: number
    photos_count: number
  }
  social: {
    facebook_followers: number
    facebook_posts_monthly: number
    facebook_engagement: string
    facebook_has_ads: boolean
    instagram_followers: number
    instagram_posts_monthly: number
    instagram_engagement: string
    instagram_has_ads: boolean
  }
  website: {
    speed_score: number
    seo_score: number
    has_ssl: boolean
  }
  overall_score: number
}

interface YourAnalysis {
  name: string
  google: {
    rating: number | null
    review_count: number
  }
  social: {
    facebook_followers: number | null
    facebook_posts_monthly: number | null
    facebook_engagement: number | null
    facebook_has_ads: boolean
    instagram_followers: number | null
    instagram_posts_monthly: number | null
    instagram_engagement: number | null
    instagram_has_ads: boolean
  }
  website: {
    speed_score: number | null
    seo_score: number | null
  }
  overall_score: number
}

interface CompetitorComparisonProps {
  yourAnalysis: YourAnalysis
  competitors: CompetitorAnalysis[]
  onBack: () => void
  onNewSearch: () => void
}

export function CompetitorComparison({ yourAnalysis, competitors, onBack, onNewSearch }: CompetitorComparisonProps) {
  var sortedCompetitors = [...competitors].sort(function(a, b) {
    return b.overall_score - a.overall_score
  })

  var leader = sortedCompetitors.length > 0 ? sortedCompetitors[0] : null

  // Calculate all averages
  var avgScore = sortedCompetitors.length > 0 
    ? Math.round(sortedCompetitors.reduce(function(sum, c) { return sum + c.overall_score }, 0) / sortedCompetitors.length) 
    : 0
  
  var avgRating = sortedCompetitors.length > 0 
    ? sortedCompetitors.reduce(function(sum, c) { return sum + (c.google.rating || 0) }, 0) / sortedCompetitors.length
    : 0
  
  var avgReviews = sortedCompetitors.length > 0 
    ? Math.round(sortedCompetitors.reduce(function(sum, c) { return sum + c.google.review_count }, 0) / sortedCompetitors.length) 
    : 0

  var avgPhotos = sortedCompetitors.length > 0 
    ? Math.round(sortedCompetitors.reduce(function(sum, c) { return sum + c.google.photos_count }, 0) / sortedCompetitors.length) 
    : 0
  
  var avgFbFollowers = sortedCompetitors.length > 0 
    ? Math.round(sortedCompetitors.reduce(function(sum, c) { return sum + c.social.facebook_followers }, 0) / sortedCompetitors.length) 
    : 0
  
  var avgIgFollowers = sortedCompetitors.length > 0 
    ? Math.round(sortedCompetitors.reduce(function(sum, c) { return sum + c.social.instagram_followers }, 0) / sortedCompetitors.length) 
    : 0

  var avgFbPosts = sortedCompetitors.length > 0 
    ? Math.round(sortedCompetitors.reduce(function(sum, c) { return sum + c.social.facebook_posts_monthly }, 0) / sortedCompetitors.length) 
    : 0

  var avgIgPosts = sortedCompetitors.length > 0 
    ? Math.round(sortedCompetitors.reduce(function(sum, c) { return sum + c.social.instagram_posts_monthly }, 0) / sortedCompetitors.length) 
    : 0

  var avgFbEngagement = sortedCompetitors.length > 0 
    ? sortedCompetitors.reduce(function(sum, c) { return sum + parseFloat(c.social.facebook_engagement) }, 0) / sortedCompetitors.length
    : 0

  var avgIgEngagement = sortedCompetitors.length > 0 
    ? sortedCompetitors.reduce(function(sum, c) { return sum + parseFloat(c.social.instagram_engagement) }, 0) / sortedCompetitors.length
    : 0

  var avgWebSpeed = sortedCompetitors.length > 0 
    ? Math.round(sortedCompetitors.reduce(function(sum, c) { return sum + c.website.speed_score }, 0) / sortedCompetitors.length) 
    : 0

  var avgSeoScore = sortedCompetitors.length > 0 
    ? Math.round(sortedCompetitors.reduce(function(sum, c) { return sum + c.website.seo_score }, 0) / sortedCompetitors.length) 
    : 0

  var competitorsWithAds = sortedCompetitors.filter(function(c) { 
    return c.social.facebook_has_ads || c.social.instagram_has_ads 
  }).length
  
  var adsPercentage = sortedCompetitors.length > 0 
    ? Math.round((competitorsWithAds / sortedCompetitors.length) * 100) 
    : 0

  // Find leaders for each metric
  function findLeaderValue(metric: string): { value: number | null; name: string } {
    var leaderVal: number | null = null
    var leaderName = ""
    
    sortedCompetitors.forEach(function(c) {
      var val: number | null = null
      if (metric === "score") val = c.overall_score
      else if (metric === "rating") val = c.google.rating
      else if (metric === "reviews") val = c.google.review_count
      else if (metric === "photos") val = c.google.photos_count
      else if (metric === "fb_followers") val = c.social.facebook_followers
      else if (metric === "fb_posts") val = c.social.facebook_posts_monthly
      else if (metric === "fb_engagement") val = parseFloat(c.social.facebook_engagement)
      else if (metric === "ig_followers") val = c.social.instagram_followers
      else if (metric === "ig_posts") val = c.social.instagram_posts_monthly
      else if (metric === "ig_engagement") val = parseFloat(c.social.instagram_engagement)
      else if (metric === "web_speed") val = c.website.speed_score
      else if (metric === "seo") val = c.website.seo_score
      
      if (val !== null && (leaderVal === null || val > leaderVal)) {
        leaderVal = val
        leaderName = c.name
      }
    })
    
    return { value: leaderVal, name: leaderName }
  }

  function formatNumber(num: number | null): string {
    if (num === null) return "N/A"
    if (num >= 1000000) return (num / 1000000).toFixed(1) + "M"
    if (num >= 1000) return (num / 1000).toFixed(1) + "k"
    return num.toString()
  }

  function getComparisonColor(yours: number | null, compare: number): string {
    if (yours === null) return "text-slate-400"
    if (yours > compare) return "text-green-600"
    if (yours < compare) return "text-red-600"
    return "text-slate-600"
  }

  function getDifferenceDisplay(yours: number | null, compare: number, isDecimal?: boolean): string {
    if (yours === null) return "—"
    var diff = yours - compare
    var formatted = isDecimal ? diff.toFixed(1) : formatNumber(Math.abs(diff))
    if (diff > 0) return "↑ +" + (isDecimal ? diff.toFixed(1) : formatted)
    if (diff < 0) return "↓ " + (isDecimal ? diff.toFixed(1) : "-" + formatted)
    return "= 0"
  }

  function isLeader(value: number | null, metric: string): boolean {
    if (value === null) return false
    var leader = findLeaderValue(metric)
    return value >= (leader.value || 0)
  }

  function getCellClass(value: number | null, metric: string, isYou: boolean): string {
    var base = "py-3 px-3 text-center text-sm "
    if (isYou) base += "bg-indigo-50 font-semibold text-indigo-700 "
    if (value !== null && isLeader(value, metric)) base += "font-bold "
    return base
  }

  function renderValue(value: number | null, metric: string, isYou: boolean): React.ReactNode {
    var display = ""
    var isMetricLeader = value !== null && isLeader(value, metric)
    
    if (metric === "rating") {
      display = value?.toFixed(1) || "N/A"
    } else if (metric === "fb_engagement" || metric === "ig_engagement") {
      display = value !== null ? value.toFixed(1) + "%" : "N/A"
    } else if (metric === "ads") {
      return (
        <span className={value ? "text-green-600 font-medium" : "text-red-500"}>
          {value ? "Yes ✓" : "No ✗"}
        </span>
      )
    } else {
      display = formatNumber(value)
    }
    
    return (
      <span>
        {display}
        {isMetricLeader && !isYou && <span className="ml-1">🥇</span>}
      </span>
    )
  }

  // Calculate your rank
  var allScores = [yourAnalysis.overall_score, ...sortedCompetitors.map(function(c) { return c.overall_score })]
  allScores.sort(function(a, b) { return b - a })
  var yourRank = allScores.indexOf(yourAnalysis.overall_score) + 1

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Competitive Analysis</h2>
          <p className="text-slate-500">Comparing {yourAnalysis.name} against {sortedCompetitors.length} competitors</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={onNewSearch}>New Search</Button>
          <Button variant="outline" onClick={onBack}>Close</Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 text-center">
          <ScoreRing score={yourAnalysis.overall_score} size="md" />
          <div className="mt-3 font-semibold text-slate-800">Your Score</div>
          <div className="text-sm text-slate-500">Rank #{yourRank} of {sortedCompetitors.length + 1}</div>
        </div>
        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 text-center">
          <div className="text-5xl font-bold text-slate-400 mb-2">{avgScore}</div>
          <div className="font-semibold text-slate-800">Competitor Avg</div>
          <div className={"text-sm font-medium " + (yourAnalysis.overall_score >= avgScore ? "text-green-600" : "text-red-600")}>
            {yourAnalysis.overall_score >= avgScore ? "Above average!" : "Below average"}
          </div>
        </div>
        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 text-center">
          <div className="text-5xl font-bold text-yellow-500 mb-2">{leader?.overall_score || 0}</div>
          <div className="font-semibold text-slate-800">Leader Score</div>
          <div className="text-sm text-slate-500 truncate" title={leader?.name}>{leader?.name || "N/A"}</div>
        </div>
        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 text-center">
          <div className="text-5xl font-bold text-indigo-500 mb-2">{adsPercentage}%</div>
          <div className="font-semibold text-slate-800">Running Ads</div>
          <div className="text-sm text-slate-500">{competitorsWithAds} of {sortedCompetitors.length}</div>
        </div>
      </div>

      {/* Full Comparison Matrix */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6">
        <h3 className="font-semibold text-slate-800 mb-4">📊 Full Comparison Matrix</h3>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b-2 border-slate-200">
                <th className="text-left py-3 px-3 text-sm font-semibold text-slate-600 bg-slate-50 sticky left-0 min-w-[140px]">Metric</th>
                <th className="py-3 px-3 text-sm font-semibold text-white bg-indigo-600 min-w-[100px]">
                  <div className="truncate" title={yourAnalysis.name}>You</div>
                  <div className="text-xs font-normal opacity-80 truncate">{yourAnalysis.name}</div>
                </th>
                {sortedCompetitors.map(function(comp, index) {
                  return (
                    <th key={comp.place_id} className={"py-3 px-3 text-sm font-semibold min-w-[100px] " + (index === 0 ? "bg-yellow-100 text-yellow-800" : "bg-slate-50 text-slate-600")}>
                      <div className="truncate" title={comp.name}>
                        {index === 0 && "🥇 "}{comp.name.length > 12 ? comp.name.substring(0, 12) + "..." : comp.name}
                      </div>
                      <div className="text-xs font-normal opacity-70">#{index + 1}</div>
                    </th>
                  )
                })}
                <th className="py-3 px-3 text-sm font-semibold text-slate-600 bg-slate-100 min-w-[80px]">AVG</th>
                <th className="py-3 px-3 text-sm font-semibold text-slate-600 bg-green-50 min-w-[90px]">vs Avg</th>
                <th className="py-3 px-3 text-sm font-semibold text-slate-600 bg-yellow-50 min-w-[90px]">vs Leader</th>
              </tr>
            </thead>
            <tbody>
              {/* Overall Section */}
              <tr className="bg-slate-100">
                <td colSpan={sortedCompetitors.length + 5} className="py-2 px-3 text-sm font-semibold text-slate-700">📈 Overall</td>
              </tr>
              <tr className="border-b border-slate-100 hover:bg-slate-50">
                <td className="py-3 px-3 text-sm text-slate-600 bg-slate-50 sticky left-0">Visibility Score</td>
                <td className={getCellClass(yourAnalysis.overall_score, "score", true)}>{renderValue(yourAnalysis.overall_score, "score", true)}</td>
                {sortedCompetitors.map(function(comp, index) {
                  return (
                    <td key={comp.place_id} className={getCellClass(comp.overall_score, "score", false) + (index === 0 ? "bg-yellow-50" : "")}>
                      {renderValue(comp.overall_score, "score", false)}
                    </td>
                  )
                })}
                <td className="py-3 px-3 text-center text-sm bg-slate-100 font-medium">{avgScore}</td>
                <td className={"py-3 px-3 text-center text-sm font-medium bg-green-50 " + getComparisonColor(yourAnalysis.overall_score, avgScore)}>
                  {getDifferenceDisplay(yourAnalysis.overall_score, avgScore)}
                </td>
                <td className={"py-3 px-3 text-center text-sm font-medium bg-yellow-50 " + getComparisonColor(yourAnalysis.overall_score, leader?.overall_score || 0)}>
                  {getDifferenceDisplay(yourAnalysis.overall_score, leader?.overall_score || 0)}
                </td>
              </tr>

              {/* Google Section */}
              <tr className="bg-slate-100">
                <td colSpan={sortedCompetitors.length + 5} className="py-2 px-3 text-sm font-semibold text-slate-700">📍 Google Business</td>
              </tr>
              <tr className="border-b border-slate-100 hover:bg-slate-50">
                <td className="py-3 px-3 text-sm text-slate-600 bg-slate-50 sticky left-0">Rating</td>
                <td className={getCellClass(yourAnalysis.google.rating, "rating", true)}>{renderValue(yourAnalysis.google.rating, "rating", true)}</td>
                {sortedCompetitors.map(function(comp, index) {
                  return (
                    <td key={comp.place_id} className={getCellClass(comp.google.rating, "rating", false) + (index === 0 ? "bg-yellow-50" : "")}>
                      {renderValue(comp.google.rating, "rating", false)}
                    </td>
                  )
                })}
                <td className="py-3 px-3 text-center text-sm bg-slate-100 font-medium">{avgRating.toFixed(1)}</td>
                <td className={"py-3 px-3 text-center text-sm font-medium bg-green-50 " + getComparisonColor(yourAnalysis.google.rating, avgRating)}>
                  {getDifferenceDisplay(yourAnalysis.google.rating, avgRating, true)}
                </td>
                <td className={"py-3 px-3 text-center text-sm font-medium bg-yellow-50 " + getComparisonColor(yourAnalysis.google.rating, leader?.google.rating || 0)}>
                  {getDifferenceDisplay(yourAnalysis.google.rating, leader?.google.rating || 0, true)}
                </td>
              </tr>
              <tr className="border-b border-slate-100 hover:bg-slate-50">
                <td className="py-3 px-3 text-sm text-slate-600 bg-slate-50 sticky left-0">Reviews</td>
                <td className={getCellClass(yourAnalysis.google.review_count, "reviews", true)}>{renderValue(yourAnalysis.google.review_count, "reviews", true)}</td>
                {sortedCompetitors.map(function(comp, index) {
                  return (
                    <td key={comp.place_id} className={getCellClass(comp.google.review_count, "reviews", false) + (index === 0 ? "bg-yellow-50" : "")}>
                      {renderValue(comp.google.review_count, "reviews", false)}
                    </td>
                  )
                })}
                <td className="py-3 px-3 text-center text-sm bg-slate-100 font-medium">{avgReviews}</td>
                <td className={"py-3 px-3 text-center text-sm font-medium bg-green-50 " + getComparisonColor(yourAnalysis.google.review_count, avgReviews)}>
                  {getDifferenceDisplay(yourAnalysis.google.review_count, avgReviews)}
                </td>
                <td className={"py-3 px-3 text-center text-sm font-medium bg-yellow-50 " + getComparisonColor(yourAnalysis.google.review_count, leader?.google.review_count || 0)}>
                  {getDifferenceDisplay(yourAnalysis.google.review_count, leader?.google.review_count || 0)}
                </td>
              </tr>

              {/* Facebook Section */}
              <tr className="bg-slate-100">
                <td colSpan={sortedCompetitors.length + 5} className="py-2 px-3 text-sm font-semibold text-slate-700">📘 Facebook</td>
              </tr>
              <tr className="border-b border-slate-100 hover:bg-slate-50">
                <td className="py-3 px-3 text-sm text-slate-600 bg-slate-50 sticky left-0">Followers</td>
                <td className={getCellClass(yourAnalysis.social.facebook_followers, "fb_followers", true)}>{renderValue(yourAnalysis.social.facebook_followers, "fb_followers", true)}</td>
                {sortedCompetitors.map(function(comp, index) {
                  return (
                    <td key={comp.place_id} className={getCellClass(comp.social.facebook_followers, "fb_followers", false) + (index === 0 ? "bg-yellow-50" : "")}>
                      {renderValue(comp.social.facebook_followers, "fb_followers", false)}
                    </td>
                  )
                })}
                <td className="py-3 px-3 text-center text-sm bg-slate-100 font-medium">{formatNumber(avgFbFollowers)}</td>
                <td className={"py-3 px-3 text-center text-sm font-medium bg-green-50 " + getComparisonColor(yourAnalysis.social.facebook_followers, avgFbFollowers)}>
                  {getDifferenceDisplay(yourAnalysis.social.facebook_followers, avgFbFollowers)}
                </td>
                <td className={"py-3 px-3 text-center text-sm font-medium bg-yellow-50 " + getComparisonColor(yourAnalysis.social.facebook_followers, leader?.social.facebook_followers || 0)}>
                  {getDifferenceDisplay(yourAnalysis.social.facebook_followers, leader?.social.facebook_followers || 0)}
                </td>
              </tr>
              <tr className="border-b border-slate-100 hover:bg-slate-50">
                <td className="py-3 px-3 text-sm text-slate-600 bg-slate-50 sticky left-0">Posts/Month</td>
                <td className={getCellClass(yourAnalysis.social.facebook_posts_monthly, "fb_posts", true)}>{renderValue(yourAnalysis.social.facebook_posts_monthly, "fb_posts", true)}</td>
                {sortedCompetitors.map(function(comp, index) {
                  return (
                    <td key={comp.place_id} className={getCellClass(comp.social.facebook_posts_monthly, "fb_posts", false) + (index === 0 ? "bg-yellow-50" : "")}>
                      {renderValue(comp.social.facebook_posts_monthly, "fb_posts", false)}
                    </td>
                  )
                })}
                <td className="py-3 px-3 text-center text-sm bg-slate-100 font-medium">{avgFbPosts}</td>
                <td className={"py-3 px-3 text-center text-sm font-medium bg-green-50 " + getComparisonColor(yourAnalysis.social.facebook_posts_monthly, avgFbPosts)}>
                  {getDifferenceDisplay(yourAnalysis.social.facebook_posts_monthly, avgFbPosts)}
                </td>
                <td className={"py-3 px-3 text-center text-sm font-medium bg-yellow-50 " + getComparisonColor(yourAnalysis.social.facebook_posts_monthly, leader?.social.facebook_posts_monthly || 0)}>
                  {getDifferenceDisplay(yourAnalysis.social.facebook_posts_monthly, leader?.social.facebook_posts_monthly || 0)}
                </td>
              </tr>
              <tr className="border-b border-slate-100 hover:bg-slate-50">
                <td className="py-3 px-3 text-sm text-slate-600 bg-slate-50 sticky left-0">Engagement %</td>
                <td className={getCellClass(yourAnalysis.social.facebook_engagement, "fb_engagement", true)}>{yourAnalysis.social.facebook_engagement?.toFixed(1) || "N/A"}%</td>
                {sortedCompetitors.map(function(comp, index) {
                  return (
                    <td key={comp.place_id} className={getCellClass(parseFloat(comp.social.facebook_engagement), "fb_engagement", false) + (index === 0 ? "bg-yellow-50" : "")}>
                      {comp.social.facebook_engagement}%
                    </td>
                  )
                })}
                <td className="py-3 px-3 text-center text-sm bg-slate-100 font-medium">{avgFbEngagement.toFixed(1)}%</td>
                <td className={"py-3 px-3 text-center text-sm font-medium bg-green-50 " + getComparisonColor(yourAnalysis.social.facebook_engagement, avgFbEngagement)}>
                  {getDifferenceDisplay(yourAnalysis.social.facebook_engagement, avgFbEngagement, true)}
                </td>
                <td className={"py-3 px-3 text-center text-sm font-medium bg-yellow-50 " + getComparisonColor(yourAnalysis.social.facebook_engagement, parseFloat(leader?.social.facebook_engagement || "0"))}>
                  {getDifferenceDisplay(yourAnalysis.social.facebook_engagement, parseFloat(leader?.social.facebook_engagement || "0"), true)}
                </td>
              </tr>
              <tr className="border-b border-slate-100 hover:bg-slate-50">
                <td className="py-3 px-3 text-sm text-slate-600 bg-slate-50 sticky left-0">Running Ads</td>
                <td className={"py-3 px-3 text-center text-sm bg-indigo-50 font-semibold " + (yourAnalysis.social.facebook_has_ads ? "text-green-600" : "text-red-500")}>
                  {yourAnalysis.social.facebook_has_ads ? "Yes ✓" : "No ✗"}
                </td>
                {sortedCompetitors.map(function(comp, index) {
                  return (
                    <td key={comp.place_id} className={"py-3 px-3 text-center text-sm " + (index === 0 ? "bg-yellow-50 " : "") + (comp.social.facebook_has_ads ? "text-green-600" : "text-red-500")}>
                      {comp.social.facebook_has_ads ? "Yes ✓" : "No ✗"}
                    </td>
                  )
                })}
                <td className="py-3 px-3 text-center text-sm bg-slate-100 font-medium">{adsPercentage}%</td>
                <td className="py-3 px-3 text-center text-sm bg-green-50 text-slate-400">—</td>
                <td className="py-3 px-3 text-center text-sm bg-yellow-50 text-slate-400">—</td>
              </tr>

              {/* Instagram Section */}
              <tr className="bg-slate-100">
                <td colSpan={sortedCompetitors.length + 5} className="py-2 px-3 text-sm font-semibold text-slate-700">📸 Instagram</td>
              </tr>
              <tr className="border-b border-slate-100 hover:bg-slate-50">
                <td className="py-3 px-3 text-sm text-slate-600 bg-slate-50 sticky left-0">Followers</td>
                <td className={getCellClass(yourAnalysis.social.instagram_followers, "ig_followers", true)}>{renderValue(yourAnalysis.social.instagram_followers, "ig_followers", true)}</td>
                {sortedCompetitors.map(function(comp, index) {
                  return (
                    <td key={comp.place_id} className={getCellClass(comp.social.instagram_followers, "ig_followers", false) + (index === 0 ? "bg-yellow-50" : "")}>
                      {renderValue(comp.social.instagram_followers, "ig_followers", false)}
                    </td>
                  )
                })}
                <td className="py-3 px-3 text-center text-sm bg-slate-100 font-medium">{formatNumber(avgIgFollowers)}</td>
                <td className={"py-3 px-3 text-center text-sm font-medium bg-green-50 " + getComparisonColor(yourAnalysis.social.instagram_followers, avgIgFollowers)}>
                  {getDifferenceDisplay(yourAnalysis.social.instagram_followers, avgIgFollowers)}
                </td>
                <td className={"py-3 px-3 text-center text-sm font-medium bg-yellow-50 " + getComparisonColor(yourAnalysis.social.instagram_followers, leader?.social.instagram_followers || 0)}>
                  {getDifferenceDisplay(yourAnalysis.social.instagram_followers, leader?.social.instagram_followers || 0)}
                </td>
              </tr>
              <tr className="border-b border-slate-100 hover:bg-slate-50">
                <td className="py-3 px-3 text-sm text-slate-600 bg-slate-50 sticky left-0">Posts/Month</td>
                <td className={getCellClass(yourAnalysis.social.instagram_posts_monthly, "ig_posts", true)}>{renderValue(yourAnalysis.social.instagram_posts_monthly, "ig_posts", true)}</td>
                {sortedCompetitors.map(function(comp, index) {
                  return (
                    <td key={comp.place_id} className={getCellClass(comp.social.instagram_posts_monthly, "ig_posts", false) + (index === 0 ? "bg-yellow-50" : "")}>
                      {renderValue(comp.social.instagram_posts_monthly, "ig_posts", false)}
                    </td>
                  )
                })}
                <td className="py-3 px-3 text-center text-sm bg-slate-100 font-medium">{avgIgPosts}</td>
                <td className={"py-3 px-3 text-center text-sm font-medium bg-green-50 " + getComparisonColor(yourAnalysis.social.instagram_posts_monthly, avgIgPosts)}>
                  {getDifferenceDisplay(yourAnalysis.social.instagram_posts_monthly, avgIgPosts)}
                </td>
                <td className={"py-3 px-3 text-center text-sm font-medium bg-yellow-50 " + getComparisonColor(yourAnalysis.social.instagram_posts_monthly, leader?.social.instagram_posts_monthly || 0)}>
                  {getDifferenceDisplay(yourAnalysis.social.instagram_posts_monthly, leader?.social.instagram_posts_monthly || 0)}
                </td>
              </tr>
              <tr className="border-b border-slate-100 hover:bg-slate-50">
                <td className="py-3 px-3 text-sm text-slate-600 bg-slate-50 sticky left-0">Engagement %</td>
                <td className={getCellClass(yourAnalysis.social.instagram_engagement, "ig_engagement", true)}>{yourAnalysis.social.instagram_engagement?.toFixed(1) || "N/A"}%</td>
                {sortedCompetitors.map(function(comp, index) {
                  return (
                    <td key={comp.place_id} className={getCellClass(parseFloat(comp.social.instagram_engagement), "ig_engagement", false) + (index === 0 ? "bg-yellow-50" : "")}>
                      {comp.social.instagram_engagement}%
                    </td>
                  )
                })}
                <td className="py-3 px-3 text-center text-sm bg-slate-100 font-medium">{avgIgEngagement.toFixed(1)}%</td>
                <td className={"py-3 px-3 text-center text-sm font-medium bg-green-50 " + getComparisonColor(yourAnalysis.social.instagram_engagement, avgIgEngagement)}>
                  {getDifferenceDisplay(yourAnalysis.social.instagram_engagement, avgIgEngagement, true)}
                </td>
                <td className={"py-3 px-3 text-center text-sm font-medium bg-yellow-50 " + getComparisonColor(yourAnalysis.social.instagram_engagement, parseFloat(leader?.social.instagram_engagement || "0"))}>
                  {getDifferenceDisplay(yourAnalysis.social.instagram_engagement, parseFloat(leader?.social.instagram_engagement || "0"), true)}
                </td>
              </tr>

              {/* Website Section */}
              <tr className="bg-slate-100">
                <td colSpan={sortedCompetitors.length + 5} className="py-2 px-3 text-sm font-semibold text-slate-700">🌐 Website</td>
              </tr>
              <tr className="border-b border-slate-100 hover:bg-slate-50">
                <td className="py-3 px-3 text-sm text-slate-600 bg-slate-50 sticky left-0">Speed Score</td>
                <td className={getCellClass(yourAnalysis.website.speed_score, "web_speed", true)}>{renderValue(yourAnalysis.website.speed_score, "web_speed", true)}</td>
                {sortedCompetitors.map(function(comp, index) {
                  return (
                    <td key={comp.place_id} className={getCellClass(comp.website.speed_score, "web_speed", false) + (index === 0 ? "bg-yellow-50" : "")}>
                      {renderValue(comp.website.speed_score, "web_speed", false)}
                    </td>
                  )
                })}
                <td className="py-3 px-3 text-center text-sm bg-slate-100 font-medium">{avgWebSpeed}</td>
                <td className={"py-3 px-3 text-center text-sm font-medium bg-green-50 " + getComparisonColor(yourAnalysis.website.speed_score, avgWebSpeed)}>
                  {getDifferenceDisplay(yourAnalysis.website.speed_score, avgWebSpeed)}
                </td>
                <td className={"py-3 px-3 text-center text-sm font-medium bg-yellow-50 " + getComparisonColor(yourAnalysis.website.speed_score, leader?.website.speed_score || 0)}>
                  {getDifferenceDisplay(yourAnalysis.website.speed_score, leader?.website.speed_score || 0)}
                </td>
              </tr>
              <tr className="border-b border-slate-100 hover:bg-slate-50">
                <td className="py-3 px-3 text-sm text-slate-600 bg-slate-50 sticky left-0">SEO Score</td>
                <td className={getCellClass(yourAnalysis.website.seo_score, "seo", true)}>{renderValue(yourAnalysis.website.seo_score, "seo", true)}</td>
                {sortedCompetitors.map(function(comp, index) {
                  return (
                    <td key={comp.place_id} className={getCellClass(comp.website.seo_score, "seo", false) + (index === 0 ? "bg-yellow-50" : "")}>
                      {renderValue(comp.website.seo_score, "seo", false)}
                    </td>
                  )
                })}
                <td className="py-3 px-3 text-center text-sm bg-slate-100 font-medium">{avgSeoScore}</td>
                <td className={"py-3 px-3 text-center text-sm font-medium bg-green-50 " + getComparisonColor(yourAnalysis.website.seo_score, avgSeoScore)}>
                  {getDifferenceDisplay(yourAnalysis.website.seo_score, avgSeoScore)}
                </td>
                <td className={"py-3 px-3 text-center text-sm font-medium bg-yellow-50 " + getComparisonColor(yourAnalysis.website.seo_score, leader?.website.seo_score || 0)}>
                  {getDifferenceDisplay(yourAnalysis.website.seo_score, leader?.website.seo_score || 0)}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <div className="mt-4 flex gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-1"><span className="w-3 h-3 bg-indigo-100 rounded"></span> Your business</div>
          <div className="flex items-center gap-1"><span className="w-3 h-3 bg-yellow-100 rounded"></span> Leader</div>
          <div className="flex items-center gap-1"><span>🥇</span> Best in metric</div>
          <div className="flex items-center gap-1"><span className="text-green-600">↑</span> Above</div>
          <div className="flex items-center gap-1"><span className="text-red-600">↓</span> Below</div>
        </div>
      </div>

      {/* Priority Actions */}
      <div className="bg-blue-50 rounded-2xl border border-blue-200 p-6">
        <h3 className="font-semibold text-slate-800 mb-4">💡 Priority Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {yourAnalysis.google.review_count < avgReviews && (
            <div className="bg-white rounded-lg p-4">
              <div className="font-medium text-slate-800 mb-1">📝 Get More Reviews</div>
              <p className="text-sm text-slate-600">You have {avgReviews - yourAnalysis.google.review_count} fewer reviews than average. Ask satisfied customers to leave a review.</p>
            </div>
          )}
          {(yourAnalysis.social.facebook_followers || 0) < avgFbFollowers && (
            <div className="bg-white rounded-lg p-4">
              <div className="font-medium text-slate-800 mb-1">📘 Grow Facebook</div>
              <p className="text-sm text-slate-600">Competitors average {formatNumber(avgFbFollowers)} followers. Run engagement campaigns.</p>
            </div>
          )}
          {(yourAnalysis.social.instagram_followers || 0) < avgIgFollowers && (
            <div className="bg-white rounded-lg p-4">
              <div className="font-medium text-slate-800 mb-1">📸 Boost Instagram</div>
              <p className="text-sm text-slate-600">You are {formatNumber(avgIgFollowers - (yourAnalysis.social.instagram_followers || 0))} followers behind average.</p>
            </div>
          )}
          {!yourAnalysis.social.facebook_has_ads && adsPercentage > 30 && (
            <div className="bg-white rounded-lg p-4">
              <div className="font-medium text-slate-800 mb-1">📣 Consider Advertising</div>
              <p className="text-sm text-slate-600">{adsPercentage}% of competitors run Meta ads.</p>
            </div>
          )}
          {yourAnalysis.overall_score >= avgScore && (
            <div className="bg-white rounded-lg p-4">
              <div className="font-medium text-slate-800 mb-1">🎉 You are Above Average!</div>
              <p className="text-sm text-slate-600">Keep up the good work and maintain consistency.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
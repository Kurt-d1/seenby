import { NextRequest, NextResponse } from "next/server"
import { analyzeWebsite, quickWebsiteCheck } from "@/lib/pagespeed"

export async function POST(request: NextRequest) {
  try {
    var body = await request.json()
    var { url, quick } = body

    if (!url) {
      return NextResponse.json({ error: "URL is required" }, { status: 400 })
    }

    console.log("Website analysis request:", url, "quick:", quick)

    if (quick) {
      // Quick check only - no PageSpeed API call
      var quickResult = await quickWebsiteCheck(url)
      return NextResponse.json({
        accessible: quickResult.accessible,
        has_ssl: quickResult.has_ssl,
        redirect_url: quickResult.redirect_url,
        speed_score: null,
        seo_score: null
      })
    }

    // Full PageSpeed analysis
    var [quickCheck, pagespeed] = await Promise.all([
      quickWebsiteCheck(url),
      analyzeWebsite(url)
    ])

    if (!pagespeed) {
      return NextResponse.json({
        accessible: quickCheck.accessible,
        has_ssl: quickCheck.has_ssl,
        speed_score: null,
        seo_score: null,
        error: "PageSpeed analysis failed"
      })
    }

    return NextResponse.json({
      accessible: quickCheck.accessible,
      has_ssl: quickCheck.has_ssl,
      redirect_url: quickCheck.redirect_url,
      speed_score: pagespeed.performance_score,
      seo_score: pagespeed.seo_score,
      accessibility_score: pagespeed.accessibility_score,
      best_practices_score: pagespeed.best_practices_score,
      metrics: {
        first_contentful_paint: pagespeed.first_contentful_paint,
        speed_index: pagespeed.speed_index,
        largest_contentful_paint: pagespeed.largest_contentful_paint,
        time_to_interactive: pagespeed.time_to_interactive,
        total_blocking_time: pagespeed.total_blocking_time,
        cumulative_layout_shift: pagespeed.cumulative_layout_shift
      }
    })

  } catch (error) {
    console.error("Website analysis error:", error)
    return NextResponse.json({ error: "Analysis failed" }, { status: 500 })
  }
}
```

---

**File 4:** Update `.env.local` - add this line (PageSpeed works without a key but has rate limits):
```
GOOGLE_PAGESPEED_API_KEY=your_key_here